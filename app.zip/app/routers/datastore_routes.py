"""
Dynamic Datastore API — backed by AWS DynamoDB / PostgreSQL

Flow:
  1. POST /datastore/create              → define schema + create a real table
  2. POST /datastore/{table_name}/row    → insert a row — fields mapped from schema, stored as separate columns
  3. GET  /datastore/{table_name}/rows   → list all rows
  4. GET  /datastore/{table_name}/row/{id} → get one row
  5. GET  /datastore/schemas             → list all registered schemas
  6. GET  /datastore/schemas/{table_name} → get schema for one table

Each call to POST /create:
  - Creates a real table (DynamoDB PAY_PER_REQUEST or PostgreSQL CREATE TABLE)
  - If table already exists: schema metadata is updated, table left as-is
  - The datastore_schemas meta-table is auto-created on first use

Projects (PostgreSQL only):
  POST /datastore/create accepts an optional `project_id` to scope the
  new domain model to a project (see /projects routes). Physical table
  names are still globally unique in Postgres, so `project_id` is a
  grouping/ownership tag, not a namespace for the table name itself.
  GET /datastore/schemas?project_id=... lists only that project's
  domain models; omit it to list everything (unchanged, backward compatible).

Modules (PostgreSQL only) — Project → Module → Domain model:
  POST /datastore/create (and drafts) also accept an optional `module_id`
  (see /modules routes). The module must exist, and if `project_id` is
  also sent it must be the module's project; if only `module_id` is sent,
  the project is taken from the module. GET /datastore/schemas?module_id=...
  and GET /datastore/drafts?module_id=... filter by module.

Drafts (PostgreSQL only):
  A draft is a domain model saved to the database but NOT yet turned
  into real tables. POST /datastore/drafts persists it and issues no
  DDL at all; the physical tables are generated only by
  POST /datastore/drafts/{draft_id}/submit. Drafts live in their own
  domain_model_drafts table and are deliberately kept out of
  datastore_schemas, so GET /datastore/schemas (and everything reading
  it) still only ever sees submitted domain models.
  16. POST   /datastore/drafts                    → save (upsert) a draft, no tables created
  17. GET    /datastore/drafts                    → list drafts (filter by project_id / status)
  18. GET    /datastore/drafts/{draft_id}         → get one draft
  19. DELETE /datastore/drafts/{draft_id}         → discard a draft
  20. POST   /datastore/drafts/{draft_id}/submit  → generate the domain model tables

Domain attributes + multilingual labels:
  10. POST /datastore/domain-attributes                                    → save an attribute's English label
  11. GET  /datastore/domain-attributes/{domain_model_id}                  → list attributes for a domain
  12. POST /datastore/domain-attributes/{domain}/{attribute}/translation   → save one language's label for an attribute
  13. GET  /datastore/domain-attributes/{domain}/translations              → get all translations for a domain, grouped
"""
import re
from typing import Any
from fastapi import APIRouter, Body, Depends, HTTPException, Request
from pydantic import BaseModel

from ..utils.decorators import handle_errors
from ..dependencies.rbac_dependency import require_permission
from ..services import abac_service, rbac_service
from ..db.repositories import rbac_repo

router = APIRouter(prefix="/datastore", tags=["Datastore - Dynamic Tables"])


# ── Server-side field validator ────────────────────────────────

async def _apply_field_rules(request: Request, table_name: str, rows: list[dict]) -> list[dict]:
    """Hide the columns the caller's roles may not read (domain ABAC 'fields')."""
    user = getattr(request.state, "current_user", None)
    if not user or rbac_service.is_admin(user):
        return rows
    try:
        role_names = [r["name"] for r in await rbac_repo.get_user_roles(user["user_id"])]
        return await abac_service.filter_rows(role_names, table_name, rows)
    except Exception:
        return rows


async def _schema_viewer_roles(request: Request) -> list[str] | None:
    """
    Role names whose ABAC field rules must be applied to schema responses,
    or None when the schema should be returned untouched: no/invalid token
    (same as the row endpoints), admins, and anyone who can design domain
    models ("domain_model" edit, same gate as editing ABAC rules) - they need
    the full schema to build and secure it.
    """
    auth = request.headers.get("Authorization", "")
    if not auth.lower().startswith("bearer "):
        return None
    try:
        from ..core.security import verify_token
        user = verify_token(auth.split(" ", 1)[1])
    except HTTPException:
        return None
    if rbac_service.is_admin(user):
        return None
    if await rbac_service.user_has_permission(user, "domain_model", "edit"):
        return None
    return [r["name"] for r in await rbac_repo.get_user_roles(user["user_id"])]


async def _apply_schema_rules(request: Request, table_name: str, schema: list[dict]) -> list[dict]:
    """Hide the attributes the caller's roles may not read (domain ABAC 'fields')."""
    try:
        roles = await _schema_viewer_roles(request)
        if roles is None:
            return schema
        return await abac_service.filter_schema(roles, table_name, schema)
    except Exception:
        return schema


async def _apply_schemas_rules(request: Request, schemas: list[dict]) -> list[dict]:
    """Same as _apply_schema_rules for a list of {table_name, schema, ...}."""
    try:
        roles = await _schema_viewer_roles(request)
        if roles is None:
            return schemas
        return await abac_service.filter_schemas(roles, schemas)
    except Exception:
        return schemas


def _validate_row(schema: list[dict], row_data: dict) -> dict[str, str]:
    """
    Validate row_data against the schema's validation rules.
    Returns a dict of {field_id: error_message} for every failing field.
    Empty dict means all fields are valid.
    """
    errors: dict[str, str] = {}

    for field in schema:
        fid   = field.get("field_id", "")
        ftype = field.get("type", "text")
        label = field.get("label") or fid
        rules = field.get("validations") or []

        raw = row_data.get(fid)
        # Normalise to string for length/pattern checks
        str_val = str(raw).strip() if raw is not None else ""

        # ── built-in type checks ──────────────────────────────
        if ftype == "number" and str_val != "":
            try:
                float(str_val)
            except (ValueError, TypeError):
                errors[fid] = f"{label} must be a valid number"
                continue

        # ── schema-defined rules ──────────────────────────────
        for rule in rules:
            rtype   = rule.get("type", "")
            rvalue  = rule.get("value")
            rmsg    = rule.get("message") or ""

            if rtype == "required":
                if str_val == "":
                    errors[fid] = rmsg or f"{label} is required"
                    break

            elif rtype == "minLength":
                if str_val and len(str_val) < int(rvalue):
                    errors[fid] = rmsg or f"{label} must be at least {rvalue} characters"
                    break

            elif rtype == "maxLength":
                if len(str_val) > int(rvalue):
                    errors[fid] = rmsg or f"{label} must be at most {rvalue} characters"
                    break

            elif rtype == "min":
                try:
                    if str_val and float(str_val) < float(rvalue):
                        errors[fid] = rmsg or f"{label} must be at least {rvalue}"
                        break
                except (ValueError, TypeError):
                    pass

            elif rtype == "max":
                try:
                    if str_val and float(str_val) > float(rvalue):
                        errors[fid] = rmsg or f"{label} must be at most {rvalue}"
                        break
                except (ValueError, TypeError):
                    pass

            elif rtype == "pattern":
                try:
                    if str_val and not re.fullmatch(str(rvalue), str_val):
                        errors[fid] = rmsg or f"{label} format is invalid"
                        break
                except re.error:
                    pass  # ignore malformed regex

    return errors


# ── Pydantic models ────────────────────────────────────────────

class SchemaField(BaseModel):
    field_id: str
    type: str               # text | number | formattedText | boolean | date
    label: str
    value: Any = None       # optional default value

    model_config = {"extra": "allow"}


class CreateTableRequest(BaseModel):
    table_name: str
    # Business name as the user typed it (e.g. "Client Details") — table_name
    # stays the storage name (e.g. "ClientDetails"). Optional.
    label: str | None = None
    schema: list[SchemaField]
    project_id: str | int | None = None   # optional — scopes this domain model to a project
    module_id: str | int | None = None    # optional — places it in a module of that project
    # Safety net for callers that already POST here: with is_draft=true
    # this endpoint saves a draft instead of creating anything. Nothing
    # existing sets it, so the default keeps the old behaviour exactly.
    is_draft: bool = False

    model_config = {
        "json_schema_extra": {
            "example": {
                "table_name": "my_employees",
                "schema": [
                    {"field_id": "employee_name",   "type": "text",   "label": "Employee Name"},
                    {"field_id": "employee_age",    "type": "number", "label": "Employee Age"},
                    {"field_id": "employee_dept",   "type": "text",   "label": "Department"},
                    {"field_id": "employee_salary", "type": "number", "label": "Salary"},
                    {"field_id": "employee_region", "type": "text",   "label": "Region"},
                ]
            }
        }
    }


class DraftTableSpec(BaseModel):
    """One table the draft will generate when it's submitted — the exact
    same shape POST /datastore/create takes, just stored instead of
    executed."""
    table_name: str
    label: str | None = None
    schema: list[SchemaField]
    db_backend: str | None = None
    versioned: bool = False
    project_id: str | int | None = None
    module_id: str | int | None = None

    model_config = {"extra": "allow"}


class SaveDraftRequest(BaseModel):
    domain_name: str
    project_id: str | int | None = None
    module_id: str | int | None = None
    # Tables to create on submit, in the order they should be applied
    # (main domain, then related domains, then junction tables).
    tables: list[DraftTableSpec] = []
    # Opaque builder state the frontend round-trips so an unfinished
    # domain can be reopened and edited exactly as it was left.
    fields: dict[str, Any] | None = None
    payload: dict[str, Any] | None = None
    db_backend: str | None = None
    versioned: bool = False

    model_config = {"extra": "allow"}


class DomainAttributeRequest(BaseModel):
    domain_model_id: str
    attribute_name: str
    label: str | None = None
    field_type: str | None = None


class AttributeTranslationRequest(BaseModel):
    lang_code: str   # 'en' | 'ta' | 'ar'
    label: str


class ValidationRuleRequest(BaseModel):
    tag: str
    version: str | None = None
    description: str | None = None
    category: str | None = None

    # new kind-based shape
    kind: str | None = None
    expression: str | None = None
    min: float | None = None
    max: float | None = None
    validations: list[Any] | None = None

    # legacy flat shape
    type: str | None = None
    value: Any = None
    message: str | None = None


# ── Helper: safely extract schema list from repo result ────────

def _extract_schema_list(schema_result: Any) -> list[dict]:
    """
    get_schema() returns {"schema": [...], "db_backend": "..."}
    This helper safely extracts just the list regardless of shape.
    """
    if schema_result is None:
        return []
    if isinstance(schema_result, list):
        return schema_result
    if isinstance(schema_result, dict):
        inner = schema_result.get("schema", [])
        if isinstance(inner, list):
            return inner
        if isinstance(inner, str):
            import json
            try:
                return json.loads(inner)
            except Exception:
                return []
    return []


async def _resolve_scope(project_id, module_id):
    """Validate the (project, module) pair; raises an HTTP error if invalid."""
    if module_id in (None, ""):
        return project_id, None
    from ..services.module_service import resolve_scope
    r = await resolve_scope(project_id, module_id)
    if r.get("status") == "error":
        raise HTTPException(status_code=r.get("code", 400), detail=r.get("message"))
    return r["project_id"], r["module_id"]


# ── 1. Create table from schema ────────────────────────────────

@router.post("/create", summary="Create a database table from a JSON schema (DynamoDB or PostgreSQL)")
@handle_errors
async def create_table(body: CreateTableRequest, request: Request):
    from ..db.repositories.datastore_repo import create_table_from_schema, save_schema
    from ..core.config import settings

    schema = [f.model_dump() for f in body.schema]
    is_dynamo = settings.DB_BACKEND == "dynamodb"

    # Project → Module → Domain model: validate/derive the scope first.
    project_id, module_id = await _resolve_scope(body.project_id, body.module_id)

    # 0. Draft — persist it and stop. No DDL, no datastore_schemas row.
    #    The tables get generated by POST /datastore/drafts/{id}/submit.
    if body.is_draft:
        from ..db.repositories.domain_draft_repo import save_draft as _save_draft
        saved = await _save_draft(
            body.table_name,
            {
                "domain_name": body.table_name,
                "tables": [{
                    "table_name": body.table_name,
                    "label":      body.label,
                    "schema":     schema,
                    "project_id": project_id,
                    "module_id":  module_id,
                }],
            },
            project_id,
            _current_user(request),
            module_id,
        )
        return {
            **saved,
            "table_name":    body.table_name,
            "table_created": False,
            "is_draft":      True,
            "project_id":    project_id,
            "module_id":     module_id,
        }

    # 1. Create / update the physical table
    result = await create_table_from_schema(body.table_name, schema)

    # 2. Save / update schema metadata
    await save_schema(body.table_name, schema, project_id, module_id, body.label)

    action = "created" if result["created"] else "already existed"

    # Build backend-specific fields for the response
    if is_dynamo:
        backend_info = {"aws_region": settings.AWS_REGION}
        location_str = f"in AWS DynamoDB region {settings.AWS_REGION}"
    else:
        backend_info = {"pg_host": settings.DB_HOST, "pg_db": settings.DB_NAME}
        location_str = f"in PostgreSQL ({settings.DB_HOST}/{settings.DB_NAME})"

    return {
        "status":        "success",
        "table_name":    body.table_name,
        "label":         body.label,
        "table_created": result["created"],
        "action":        action,
        "db_backend":    settings.DB_BACKEND,
        "project_id":    project_id,
        "module_id":     module_id,
        **backend_info,
        "columns": [
            {"field_id": f["field_id"], "label": f["label"], "type": f["type"]}
            for f in schema
        ],
        "total_fields": len(schema),
        "message": (
            f"Table '{body.table_name}' {action} {location_str} "
            f"with {len(schema)} field(s). Primary key: id."
        ),
    }


# ── Drafts ─────────────────────────────────────────────────────
# Registered before the dynamic /{table_name}/... routes below so a
# literal "drafts" path segment is never swallowed by table_name.

def _current_user(request: Request) -> str | None:
    """Best-effort creator stamp from the bearer token. A missing or
    malformed token just means an unattributed draft — it must never
    block saving one."""
    try:
        auth = request.headers.get("Authorization", "")
        if not auth.lower().startswith("bearer "):
            return None
        from ..core.security import verify_token
        payload = verify_token(auth.split(" ", 1)[1]) or {}
        user = payload.get("email") or payload.get("user_id")
        return str(user) if user is not None else None
    except Exception:
        return None


@router.post("/drafts", summary="Save a domain model as a DRAFT — stored in the DB, no tables created")
@handle_errors
async def save_draft_route(body: SaveDraftRequest, request: Request):
    """
    Persists the whole in-progress domain model (its fields, UI hints,
    relations, junction tables — everything) as one row in
    domain_model_drafts. Nothing is created in the schema: no
    CREATE TABLE, no ALTER TABLE, no datastore_schemas entry. The
    domain model only becomes real tables when the draft is submitted
    via POST /datastore/drafts/{draft_id}/submit.

    Upserts on (domain_name, project_id), so repeatedly saving the same
    domain updates the one draft rather than piling up copies.
    """
    from ..db.repositories.domain_draft_repo import save_draft as _save

    if not body.domain_name.strip():
        raise HTTPException(status_code=400, detail="domain_name is required")

    project_id, module_id = await _resolve_scope(body.project_id, body.module_id)
    payload = body.model_dump()
    payload["project_id"], payload["module_id"] = project_id, module_id
    result = await _save(
        body.domain_name.strip(),
        payload,
        project_id,
        _current_user(request),
        module_id,
    )
    if result.get("status") == "error":
        raise HTTPException(status_code=400, detail=result.get("message", "Could not save draft"))
    return result


@router.get("/drafts", summary="List saved drafts (optionally filtered by project_id / status)")
@handle_errors
async def list_drafts_route(
    request: Request,
    project_id: str | None = None,
    status: str | None = "draft",
    module_id: str | None = None,
):
    from ..db.repositories.domain_draft_repo import list_drafts as _list
    # status=all → include already-submitted ones too (history view).
    drafts = await _list(
        project_id, None if status in (None, "", "all") else status, module_id,
    )
    return {
        "status":     "success",
        "count":      len(drafts),
        "project_id": project_id,
        "module_id":  module_id,
        "drafts":     drafts,
    }


@router.get("/drafts/{draft_id}", summary="Get one draft by id")
@handle_errors
async def get_draft_route(draft_id: str, request: Request):
    from ..db.repositories.domain_draft_repo import get_draft as _get
    draft = await _get(draft_id)
    if not draft:
        raise HTTPException(status_code=404, detail=f"Draft '{draft_id}' not found")
    return {"status": "success", "draft": draft}


@router.delete("/drafts/{draft_id}", summary="Discard a draft")
@handle_errors
async def delete_draft_route(draft_id: str, request: Request):
    from ..db.repositories.domain_draft_repo import delete_draft as _delete
    result = await _delete(draft_id)
    if result.get("status") == "error":
        raise HTTPException(status_code=404, detail=result.get("message", "Draft not found"))
    return result


@router.post("/drafts/{draft_id}/submit", summary="Submit a draft — generates the domain model tables")
@handle_errors
async def submit_draft_route(draft_id: str, request: Request):
    """
    The single point where a draft turns into real tables: each stored
    table spec goes through the same create_table_from_schema +
    save_schema path a direct POST /datastore/create would take, in the
    order the draft recorded (main domain → related domains → junction
    tables). On any failure the draft stays open so it can be fixed and
    resubmitted — a partial submit is never marked done.
    """
    from ..db.repositories.domain_draft_repo import submit_draft as _submit
    result = await _submit(draft_id)
    if result.get("status") == "error":
        raise HTTPException(status_code=400, detail=result)
    return result


# ── 2. Insert a row ────────────────────────────────────────────

@router.post("/{table_name}/row", dependencies=[Depends(require_permission("create"))], summary="Insert a row — each field stored as a separate column")
@handle_errors
async def insert_row(table_name: str, request: Request, body: dict[str, Any] = Body(...)):
    from ..db.repositories.datastore_repo import get_schema, insert_row as _insert

    schema_result = await get_schema(table_name)
    if not schema_result:
        raise HTTPException(
            status_code=404,
            detail=f"No schema found for table '{table_name}'. Create it first via POST /datastore/create"
        )

    schema = _extract_schema_list(schema_result)
    if not schema:
        raise HTTPException(
            status_code=404,
            detail=f"Schema for '{table_name}' is empty or unreadable."
        )

    # ── Server-side validation ────────────────────────────
    validation_errors = _validate_row(schema, body)
    if validation_errors:
        raise HTTPException(
            status_code=422,
            detail={"message": "Validation failed", "errors": validation_errors}
        )

    # Show the mapping: schema field → input value → stored type
    mapping = []
    for field in schema:
        fid   = field["field_id"]
        ftype = field.get("type", "text")
        val   = body.get(fid)
        mapping.append({
            "field_id":       fid,
            "label":          field.get("label"),
            "schema_type":    ftype,
            "value_received": val,
            "stored_as":      "Number (N)" if ftype == "number" else
                              "Boolean (BOOL)" if ftype == "boolean" else
                              "String (S)",
        })

    record_id = await _insert(table_name, schema, body)

    return {
        "status":        "success",
        "table_name":    table_name,
        "record_id":     record_id,
        "field_mapping": mapping,
    }


# ── 3. List all rows ───────────────────────────────────────────

def _filter_rows_by_query(rows: list[dict], params) -> list[dict]:
    """Keep rows whose column equals the query-string value.

    - ?col=a            -> col == "a"
    - ?col=a&col=b      -> col in ("a", "b")   (repeat the key for "any of")
    - Compared as text (ids and numbers come back as strings from the API).
    - Names that are not a column of the returned rows are ignored, so unknown
      params (cache-busters, typos) behave as before: nothing is filtered.
    - Empty values are ignored.
    """
    if not rows:
        return rows
    columns = set(rows[0].keys())
    wanted: dict[str, set[str]] = {}
    for key, value in params:
        if key in columns and value != "":
            wanted.setdefault(key, set()).add(value)
    if not wanted:
        return rows
    return [
        row for row in rows
        if all(str(row.get(col)) in values for col, values in wanted.items())
    ]


@router.get("/{table_name}/rows", dependencies=[Depends(require_permission("view"))], summary="List all rows in a dynamic table")
@handle_errors
async def list_rows(table_name: str, request: Request):
    from ..db.repositories.datastore_repo import list_rows as _list
    rows = await _list(table_name)
    rows = await _apply_field_rules(request, table_name, rows)
    # Optional column filters: GET /datastore/Department/rows?departmentName=BIO
    # Applied AFTER field rules so only columns the caller may see can be filtered on.
    rows = _filter_rows_by_query(rows, request.query_params.multi_items())
    return {"status": "success", "table_name": table_name, "count": len(rows), "data": rows}


# ── 4. Get one row ─────────────────────────────────────────────

@router.get("/{table_name}/row/{record_id}", dependencies=[Depends(require_permission("view"))], summary="Get one row by ID")
@handle_errors
async def get_row(table_name: str, record_id: str, request: Request):
    from ..db.repositories.datastore_repo import get_row as _get
    row = await _get(table_name, record_id)
    if not row:
        raise HTTPException(status_code=404, detail="Row not found")
    row = (await _apply_field_rules(request, table_name, [row]))[0]
    return {"status": "success", "table_name": table_name, "data": row}


# ── Config: get / switch active DB backend ────────────────────

@router.get("/config", summary="Get the active DB backend")
@handle_errors
async def get_config(request: Request):
    from ..db.repositories.datastore_repo import get_backend
    return {"status": "success", "db_backend": get_backend()}


@router.post("/config", summary="Switch the active DB backend (dynamodb | postgresql)")
@handle_errors
async def update_config(request: Request, body: dict[str, Any] = Body(...)):
    backend = body.get("db_backend", "")
    if backend not in ("dynamodb", "postgresql"):
        raise HTTPException(
            status_code=400,
            detail="db_backend must be 'dynamodb' or 'postgresql'"
        )
    from ..db.repositories.datastore_repo import set_backend
    set_backend(backend)
    return {"status": "success", "db_backend": backend}


# ── 5. List all schemas ────────────────────────────────────────

@router.get("/schemas", summary="List all registered schemas (optionally filtered by project_id / module_id)")
@handle_errors
async def list_schemas(
    request: Request,
    project_id: str | None = None,
    module_id: str | None = None,
):
    from ..db.repositories.datastore_repo import list_schemas as _list
    schemas = await _list(project_id, module_id)
    schemas = await _apply_schemas_rules(request, schemas)
    return {
        "status": "success", "count": len(schemas), "schemas": schemas,
        "project_id": project_id, "module_id": module_id,
    }


# ── 6. Get schema for one table ────────────────────────────────

@router.get("/schemas/{table_name}", summary="Get schema definition for a table")
@handle_errors
async def get_schema_route(table_name: str, request: Request):
    from ..db.repositories.datastore_repo import get_schema as _get
    schema_result = await _get(table_name)
    if not schema_result:
        raise HTTPException(
            status_code=404,
            detail=f"Schema not found for '{table_name}'"
        )

    schema_list = _extract_schema_list(schema_result)
    schema_list = await _apply_schema_rules(request, table_name, schema_list)
    db_backend  = schema_result.get("db_backend", "postgresql") if isinstance(schema_result, dict) else "postgresql"

    return {
        "status":     "success",
        "table_name": table_name,
        "label":      schema_result.get("label") if isinstance(schema_result, dict) else None,
        "schema":     schema_list,
        "db_backend": db_backend,
    }


# ── 6b. Domain model management (edit / delete) ────────────────

class RenameDomainRequest(BaseModel):
    new_table_name: str | None = None
    # Send label (empty string / null clears it) to change the business name.
    label: str | None = None
    # Send project_id / module_id (null clears them) to move the domain.
    project_id: str | int | None = None
    module_id: str | int | None = None

    model_config = {"extra": "forbid"}


class UpdateFieldRequest(BaseModel):
    new_field_id: str | None = None
    type: str | None = None
    label: str | None = None


def _raise_if_error(result: dict):
    if result.get("status") == "error":
        raise HTTPException(status_code=result.get("code", 400), detail=result.get("message", "Request failed"))


@router.put("/schemas/{table_name}", summary="Rename a domain model and/or move it to another project/module")
@handle_errors
async def update_domain_route(table_name: str, body: RenameDomainRequest, request: Request):
    from ..db.repositories.datastore_repo import rename_domain as _rename
    fields_sent = body.model_fields_set
    move = "project_id" in fields_sent or "module_id" in fields_sent
    project_id, module_id = body.project_id, body.module_id
    if move:
        project_id, module_id = await _resolve_scope(project_id, module_id)
    update_label = "label" in fields_sent
    result = await _rename(
        table_name, body.new_table_name or table_name, project_id, module_id, move,
        body.label, update_label,
    )
    _raise_if_error(result)
    # Keep the domain's ABAC rules attached if the domain model was renamed.
    new_name = body.new_table_name or table_name
    if new_name != table_name:
        from ..services import abac_service
        await abac_service.rename_domain(table_name, new_name)
    return result


@router.delete("/schemas/{table_name}", summary="Delete a domain model (schema, attributes and — by default — its table and data)")
@handle_errors
async def delete_domain_route(table_name: str, request: Request, drop_table: bool = True):
    from ..db.repositories.datastore_repo import delete_domain as _delete
    result = await _delete(table_name, drop_table)
    _raise_if_error(result)
    # Remove the deleted domain's ABAC rules so none are left orphaned.
    from ..services import abac_service
    await abac_service.delete_rules(table_name)
    return result


@router.put("/schemas/{table_name}/fields/{field_id}", summary="Rename and/or retype one attribute of a domain model")
@handle_errors
async def update_field_route(table_name: str, field_id: str, body: UpdateFieldRequest, request: Request):
    from ..db.repositories.datastore_repo import update_field as _update
    result = await _update(table_name, field_id, body.new_field_id, body.type, body.label)
    _raise_if_error(result)
    return result


@router.delete("/schemas/{table_name}/fields/{field_id}", summary="Delete one attribute (schema entry, column and labels)")
@handle_errors
async def delete_field_route(table_name: str, field_id: str, request: Request):
    from ..db.repositories.datastore_repo import delete_field as _delete
    result = await _delete(table_name, field_id)
    _raise_if_error(result)
    return result


# ── 7. Update a row ────────────────────────────────────────────

@router.put("/{table_name}/row/{record_id}", dependencies=[Depends(require_permission("edit"))], summary="Update a row by ID")
@handle_errors
async def update_row(table_name: str, record_id: str, request: Request, body: dict[str, Any] = Body(...)):
    from ..db.repositories.datastore_repo import update_row as _update
    result = await _update(table_name, record_id, body)
    if result.get("status") == "error":
        raise HTTPException(status_code=400, detail=result.get("message", "Update failed"))
    return {"status": "success", "record_id": record_id}


# ── 8. Delete a row ────────────────────────────────────────────

@router.delete("/{table_name}/row/{record_id}", dependencies=[Depends(require_permission("delete"))], summary="Delete a row by ID")
@handle_errors
async def delete_row(table_name: str, record_id: str, request: Request):
    from ..db.repositories.datastore_repo import delete_row as _delete
    result = await _delete(table_name, record_id)
    if result.get("status") == "error":
        raise HTTPException(status_code=400, detail=result.get("message", "Delete failed"))
    return {"status": "success", "record_id": record_id}


# ── 8b. Restore an archived row ────────────────────────────────

@router.post("/{table_name}/row/{record_id}/restore", dependencies=[Depends(require_permission("edit"))], summary="Restore an archived (soft-deleted) row")
@handle_errors
async def restore_row_route(table_name: str, record_id: str, request: Request):
    from ..db.repositories.datastore_repo import restore_row as _restore
    result = await _restore(table_name, record_id)
    if result.get("status") == "error":
        raise HTTPException(status_code=result.get("code", 400), detail=result.get("message", "Restore failed"))
    return {"status": "success", "record_id": record_id}


# ── 9. List archived rows ──------------------------------------

@router.get("/{table_name}/archived", dependencies=[Depends(require_permission("view"))], summary="List soft-deleted (archived) rows")
@handle_errors
async def list_archived_rows(table_name: str, request: Request):
    from ..db.repositories.datastore_repo import list_archived_rows as _list_archived
    rows = await _list_archived(table_name)
    return {"status": "success", "table_name": table_name, "count": len(rows), "data": rows}


# ── 10. Save domain attribute ──────────────────────────────────

@router.post("/domain-attributes", summary="Save an attribute (field) belonging to a domain model")
@handle_errors
async def save_domain_attribute(body: DomainAttributeRequest, request: Request):
    from ..db.repositories.datastore_repo import save_domain_attribute as _save
    result = await _save(body.domain_model_id, body.attribute_name, body.label, body.field_type)
    return result


# ── 11. List attributes for a domain ──────────────────────────

@router.get("/domain-attributes/{domain_model_id}", summary="List all attributes for a domain model")
@handle_errors
async def list_domain_attributes(domain_model_id: str, request: Request):
    from ..db.repositories.datastore_repo import list_domain_attributes as _list
    attributes = await _list(domain_model_id)
    return {
        "status":          "success",
        "domain_model_id": domain_model_id,
        "count":           len(attributes),
        "data":            attributes,
    }


# ── 12. Save one language's label for one attribute ───────────

@router.post(
    "/domain-attributes/{domain_model_id}/{attribute_name}/translation",
    summary="Save one language's translated label for an attribute",
)
@handle_errors
async def save_attribute_translation(
    domain_model_id: str,
    attribute_name: str,
    body: AttributeTranslationRequest,
    request: Request,
):
    """
    Body:
        { "lang_code": "ta", "label": "கிளினிக் பெயர்" }

    Upserts ONE row in attribute_translations (linked via FK to the
    domain_attributes row for this domain + attribute). The attribute
    must already exist (saved via POST /domain-attributes) before its
    translations can be saved.
    """
    from ..db.repositories.datastore_repo import save_attribute_translation as _save

    if body.lang_code not in ("en", "ta", "ar"):
        raise HTTPException(status_code=400, detail="lang_code must be 'en', 'ta', or 'ar'")
    if not body.label.strip():
        raise HTTPException(status_code=400, detail="label cannot be empty")

    result = await _save(domain_model_id, attribute_name, body.lang_code, body.label.strip())
    if result.get("status") == "error":
        raise HTTPException(status_code=404, detail=result.get("message", "Could not save translation"))
    return result


# ── 13. Get all attributes + translations for a domain, as nested JSON ─

@router.get(
    "/domain-attributes/{domain_model_id}/translations",
    summary="Get all attribute translations for a domain, grouped by attribute",
)
@handle_errors
async def get_domain_translations(domain_model_id: str, request: Request):
    """
    Returns translations grouped by attribute_name — ready for the
    frontend's resolveLabel() to consume directly:

        {
          "status": "success",
          "domain_model_id": "clinic",
          "data": {
            "clinic_name": { "en": "Clinic Name", "ta": "கிளினிக் பெயர்", "ar": "اسم العيادة" },
            "ph_no":       { "en": "Phone Number", "ta": "தொலைபேசி எண்", "ar": "رقم الهاتف" }
          }
        }
    """
    from ..db.repositories.datastore_repo import get_domain_translations as _get

    grouped = await _get(domain_model_id)
    return {
        "status":          "success",
        "domain_model_id": domain_model_id,
        "data":            grouped,
    }


# ── 14. List all validation rules ──────────────────────────────

@router.get("/validation-rules", summary="List every named validation rule in the registry")
@handle_errors
async def list_validation_rules_route(request: Request):
    from ..db.repositories.datastore_repo import list_validation_rules as _list
    rules = await _list()
    return {"status": "success", "count": len(rules), "rules": rules}


# ── 15. Create or update a validation rule ─────────────────────

@router.post("/validation-rules", summary="Create or update (upsert, keyed by tag) a named validation rule")
@handle_errors
async def save_validation_rule_route(body: ValidationRuleRequest, request: Request):
    """
    Upserts one row in validation_rules, keyed by `tag`. Backs the
    "Create new rule" flow in the Schema Inspector's field builder — see
    apiSaveValidationRule() in the frontend's datastoreApi.ts.
    """
    from ..db.repositories.datastore_repo import save_validation_rule as _save

    if not body.tag.strip():
        raise HTTPException(status_code=400, detail="tag is required")

    rule = body.model_dump(exclude={"tag"}, exclude_none=True)
    result = await _save(body.tag.strip(), rule)
    if result.get("status") == "error":
        raise HTTPException(status_code=400, detail=result.get("message", "Could not save validation rule"))
    return result

@router.delete("/validation-rules/{tag}")
async def delete_validation_rule_endpoint(tag: str):
    from app.db.repositories.postgres.datastore_repo import delete_validation_rule
    result = await delete_validation_rule(tag)
    if result.get("status") != "success":
        raise HTTPException(status_code=500, detail=result.get("message"))
    return result